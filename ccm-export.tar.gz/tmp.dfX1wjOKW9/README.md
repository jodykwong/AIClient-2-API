# CCM Configuration Export

这是从Linux机器导出的CCM配置文件包。

## 安装步骤

### 1. 解压文件
```bash
tar -xzf ccm-export.tar.gz
cd ccm-export
```

### 2. 安装ccm脚本
```bash
# 创建目录
mkdir -p ~/.local/share/ccm

# 复制ccm脚本
cp .local/share/ccm/ccm.sh ~/.local/share/ccm/
chmod +x ~/.local/share/ccm/ccm.sh

# 复制语言文件(如果存在)
if [ -d .local/share/ccm/lang ]; then
    cp -r .local/share/ccm/lang ~/.local/share/ccm/
fi
```

### 3. 配置API密钥
```bash
# 复制配置文件模板
cp .ccm_config ~/.ccm_config

# 使用编辑器填入你的API密钥
vim ~/.ccm_config  # 或使用 nano, code 等编辑器
```

### 4. 添加别名到shell配置
在 `~/.zshrc` 或 `~/.bashrc` 中添加:
```bash
# CCM - Claude Code Model Switcher
alias ccm='~/.local/share/ccm/ccm.sh'
```

### 5. 重新加载shell配置
```bash
source ~/.zshrc  # 或 source ~/.bashrc
```

### 6. 测试安装
```bash
ccm status
```

## macOS特殊说明

在macOS上，ccm支持Claude Pro账号管理，使用Keychain存储凭证:

```bash
# 保存当前Claude Pro账号
ccm save-account personal

# 切换账号
ccm switch-account work

# 列出所有账号
ccm list-accounts
```

## 常用命令

```bash
# 切换到Deepseek
eval "$(ccm deepseek)"

# 切换到Claude Haiku
eval "$(ccm haiku)"

# 查看当前状态
ccm status

# 编辑配置
ccm config
```

## 注意事项

- 所有API密钥已被脱敏，需要手动填入
- KIRO配置使用的是Tailscale地址，macOS上可能需要调整
- 建议根据实际网络环境调整BASE_URL配置
